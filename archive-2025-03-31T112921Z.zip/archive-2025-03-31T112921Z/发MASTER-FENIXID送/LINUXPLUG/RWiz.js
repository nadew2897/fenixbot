const randomWishes = [
        "Good Day! 🌅", 
        "Hello there! 👋", 
        "Hi, welcome! 😊", 
        "Have a great day! 🌟", 
        "Stay awesome! 😎", 
        "Hope you're doing well! 💪", 
        "Good to see you! 👀", 
        "Wishing you all the best! 🍀", 
        "Cheers! 🥂", 
        "Stay positive! ✨", 
        "Enjoy your day! 🏖️", 
        "Hello and welcome aboard! 🚀", 
        "Thanks for reaching out! 🙏", 
        "Be happy, always! 😊", 
        "Stay strong! 💪", 
        "Sending good vibes your way! 🌈", 
        "Hope you're having a fantastic day! 🎉", 
        "You're amazing! 🌟", 
        "Keep shining! ✨", 
        "So glad to connect with you! 🤝"
    ];
       
module.exports = { randomWishes };