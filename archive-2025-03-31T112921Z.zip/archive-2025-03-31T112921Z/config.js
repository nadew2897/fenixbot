module.exports = {
    /** ─── Auto Features ─────  */
    autoLikeStatus: true,
    /** ─── Owner Information ─── */
    ownerNumber: '94768413434',

    /** ─── Bot Details ──────── */
    botDetails: {
        botName: '`• 🦄 N_A_Dewzzz | Boy | 18 | Hambantota`',
        botLocation: '> ඔයාව සේව් | මාවත් සේව් කරගන්න',
        botAge: '`🐋18`',
        botEmail: 'privateloginemails@gmail.com',
    },

    /** ─── Fenix Custom Messages ────── */
    fenixaboutype: 'Programming',  // Specify your value
    fenixwel1: 'Hellow',
    fenixwel2: '`🌊Mr Tadashy🦄💗`',
    fenixwhatisay: '`ඔයාගෙ number එක ගත්තෙ status එකකින්`',

    emojis: [
        '🌼', 
        '😂', 
        '🔥', 
        '🤍', 
        '🥰', 
        '😎', 
        '🪻', 
        '🎉', 
        '👑', 
        '🛒', 
        '🚀', 
        '💎', 
        '🌟', 
        '🧘‍♀️', 
        '🌈'
    ],

    /** ─── Supported Translations of "Send" ─── */
    sendTranslations: [
        "send", 
        "එවාන්", 
        "එවපම්", 
        "එවපන්", 
        "senden", 
        "ඕනේ", 
        "ඔනි", 
        "ඔනෙ", 
        "එවන්", 
        "එවන්න", 
        "එවන්න්", 
        "එව්න්න", 
        "one", 
        "danna", 
        "ewnna", 
        "ewpm", 
        "sent", 
        "ewn", 
        "එවන්න", 
        "ඔනෙ", 
        "ඔන", 
        "දාන්න", 
        "දාපම්", 
        "එවපං", 
        "දහම්", 
        "එවපන්", 
        "දපන්", 
        "දාපන්", 
        "දාපම්", 
        "ඔනා", 
        "ඔනේ", 
        "එවහන්", 
        "One", 
        "දෙන්නකො", 
        "SEND"
    ]
};